#include <iostream>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <string>
#include <stdlib.h>
#include <queue>
#include <semaphore.h>
#include <list>
#include <iterator>

using namespace std;

#define NUM_THREADS 5
#define MEMORY_SIZE 10

struct node
{
	int id;
	int size;
};

struct mem
{
	int id;
	int size;
	int index;
};


list<mem> mylist;

///sem_destroy(&)->Sil    sem_post(&)->up sem_wait(&)->Down
queue<node> myqueue; // shared que
pthread_mutex_t sharedLock = PTHREAD_MUTEX_INITIALIZER; // mutex
pthread_t server; // server thread handle
sem_t semlist[NUM_THREADS]; // thread semaphores

int thread_message[NUM_THREADS]; // thread memory information
char  memory[MEMORY_SIZE]; // memory size

int index = 0;
bool check = true;
bool termination = false;

void release_function()
{
	//This function will be called
	//whenever the memory is no longer needed.
	//It will kill all the threads and deallocate all the data structures.
  int i = 0;
  while(!myqueue.empty() && i !=5 )
	{
    myqueue.pop();
    sem_destroy(&semlist[i]);
    i++;
  }
	//deallocate mylist
	while (mylist.front != NULL)
	{
		mem* tmpNode = mylist.front;
		delete mylist.front;
		mylist.front = tmpNode;
	}
}

int my_malloc(int thread_id, int size)
{
	//This function will add the struct to the queue
  node queueNode;
  queueNode.id = thread_id;
  queueNode.size = size;
	pthread_mutex_lock(&sharedLock);
  myqueue.push(queueNode);
	pthread_mutex_unlock(&sharedLock);

	// list <mem> iterator it = mylist.begin();
	// advance(it, size);
	//
	// if(*it == 0)
	// 	return true; //returns true if memory is not allocated
	// return false; //returns false if memory is allocated

	sem_wait(&semlist[thread_id]);
	return thread_message[thread_id];
}

void * server_function(void *)
{
	//This function should grant or decline a thread depending on memory size.
	while(check)
	{
		int memInd = -1;
		pthread_mutex_lock(&sharedLock);
		if(!myqueue.empty())
		{
			for (auto it = mylist.begin(); it != mylist.end(); ++it)
			{
				if(it->size >= myqueue.front().size && it->id == -1)
				{
					memInd = it->index;
				}
			}
			if(memInd != -1)
			{
				allocateList(mylist, myqueue.front().size, myqueue.front().id );
				for (size_t i = 0; i < myqueue.front().size; i++)
				{
					memory[memInd+i] = myqueue.front().id;
				}
				dump_memory();
				thread_message[myqueue.front().id] = memInd;
			}
			else
			{
				thread_message[myqueue.front().id] = -1;
			}
			myqueue.pop();
			sem_post(&semlist[myqueue.front().id]);
		}
	}
}

void * thread_function(void * id)
{
	srand(time(NULL));
	while(!termination)
	{
		int *intID = (int*)id;
		int randSize = rand()%( (MEMORY_SIZE/3) - 1 + 1) + 1;

		if(	my_malloc(*intID, randSize) != -1	)
		{
			use_mem();
			free_mem(intID,randSize);
		}
	}
}
void use_mem()
{
	int randTime = (rand()%(5 - 1 + 1) + 1);
	sleep(randTime);
}

void freeList(list<mem> & l, int size, int id)
{
	bool c = true;
	mem * del = new mem;
	list<mem>::iterator temp = l.begin();
	int i = 0;
	while(temp != l.end()) //search
	{
			if(temp->id == id && temp->size == size)
			{
				c = false;
			}
			else
			{
				advance (temp,i);
				i++;
			}
	}

	// if(c == false)
	// {
	// 	if(del == l.front)//firs elt
	// 	{
	// 		if()//right is hole
	// 	}
	// 	else if()//last elt
	// 	{
	// 		if()//left is hole
	// 		{
	//
	// 		}
	// 	}
	// 	else
	// 	{
	// 		if() //left and right is hole
	// 		{
	//
	// 		}
	// 		else if() //right is hole
	// 		{
	//
	// 		}
	// 		else if() //left is hole
	// 		{
	//
	// 		}
	// 		else //both sides are not hole
	// 		{
	//
	// 		}
	// 	}
	//
	// }

}

void allocateList(list<mem> & l, int size, int id)
{
	for (auto it = l.begin(); it != l.end(); ++it)
	{
		if(it->id == -1 && it->size == size)
		{
			it->id = id;
			it->size = 0;
		}
		else if(it->id == -1 && it->size > size)
		{
			it->size -= size;
			mem *newNode = new mem;
			newNode->id = id;
			newNode->size = size;
			newNode->index = it->size;
			l.push_back(*newNode);
		}
	}
}

void free_mem(int *id, int size)
{
	pthread_mutex_lock(&sharedLock);
	freeList(mylist,size,MEMORY_SIZE);
	for(int i = 0; i < size; i++)
	{
		memory[thread_message[*id]+i] = -1;
	}

	freeList(mylist, size, *id);

	pthread_mutex_unlock(&sharedLock);
}

void init()
{
	pthread_mutex_lock(&sharedLock);	//lock
	for(int i = 0; i < NUM_THREADS; i++) //initialize semaphores
	{sem_init(&semlist[i],0,0);}
	for (int i = 0; i < MEMORY_SIZE; i++)	//initialize memory
  	{char zero = 'X'; memory[i] = zero;}

	//List initialization
	mem *mainNode = new mem;
	mainNode->id = -1;
	mainNode->size = MEMORY_SIZE;
	mainNode->index = 0;
	mylist.push_back(*mainNode);

	allocateList(mylist,-1,MEMORY_SIZE);

   	pthread_create(&server,NULL,server_function,NULL); //start server
	pthread_mutex_unlock(&sharedLock); //unlock
}

void dump_memory()
{
	cout << "List:\n";
	for (auto it = mylist.begin(); it != mylist.end(); ++it)
	{
		cout << "[" << it->id << "]" << "[" << it->size << "]" <<"[" << it->index << "]\n";
	}

	cout << "Memory Dump:\n" ;
	for (int i = 0; i < MEMORY_SIZE; i++)
	{
		if(memory[i] == -1)
		{
			cout << "X" ;
		}
		else
		{
			cout << memory[i];
		}
	}
	cout << "\n*********************************\n";
}


int main (int argc, char *argv[])
 {
   pthread_t threadArray[NUM_THREADS];
   int idArray[NUM_THREADS];

   for (int i = 0; i < NUM_THREADS; i++)
	 {
     pthread_t ceren;
     threadArray[i] = ceren;
     idArray[i] = i;
   }
 	//You need to create a thread ID array here

 	init();	// call init
 	//You need to create threads with using thread ID array, using pthread_create()
  for(int i = 0; i < NUM_THREADS; i++)
	{
    pthread_create(&threadArray[i], NULL, thread_function ,(void *)&idArray[i]);
  }
	check = false;

	sleep(10);
	termination = true;
	release_function();
	cout << "\nTerminating...\n";

 }
